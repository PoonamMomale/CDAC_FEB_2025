
class Demo {
	public static void main(String args[]) {

 		double c = 25;

       		double f = (c * 9/5) + 32;
       		System.out.println(c+"\u00B0C is equal to "+f+"\u00B0F");

  	}
}