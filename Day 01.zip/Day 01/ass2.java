class Demo {
	public static void main(String args[]) {
		int a = 74;
		int b = 36;
		int c = a+b;
		System.out.println("Sum of two numbers is "+c);
	}
}