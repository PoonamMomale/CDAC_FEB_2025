class Demo {
	public static void main(String args[]) {
		int a = -5+8*6;
		System.out.println("Result of -5+8*6 is "+a);

	        int b = (55+9)%9;
		System.out.println("Result of (55+9)%9 is "+b);

	        int c = 20+-3*5/8;
		System.out.println("Result of 20+-3*5/8 is "+c);

		int d = 5+15/3*2-8%3;
		System.out.println("Result of 5+15/3*2-8%3 is "+d);
	}
}