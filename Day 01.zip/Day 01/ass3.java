class Demo {
	public static void main(String args[]) {
		int a = 50;
		int b = 3;
		int c = a/b;
		System.out.println("Division of two numbers is "+c);
	}
}